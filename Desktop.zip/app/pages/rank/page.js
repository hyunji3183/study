import React from 'react'

export default function page() {
  return (
    <div>
      랭킹이요~
    </div>
  )
}
